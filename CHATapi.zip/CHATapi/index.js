const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mysql=require('mysql2');
const config= require('./config');
const connection=mysql.createConnection(config.db);
 connection.connect((error)=>{
     if(error){
     console.log("Error connection  database:",error);
     return;
    }
    console.log("Database is connected Successfully")

 });


 app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());



const registerUser = require('./routes/userRegister');

  const message = require('./routes/chat');

  const newchat = require('./routes/newchat');


app.use('/chat', message);
app.use('/api',registerUser);
app.use('/chatting', newchat );

app.use((req, res, next) => {
    res.status(404).json({
        error: 'Bad request'
    })
})

module.exports = app;





