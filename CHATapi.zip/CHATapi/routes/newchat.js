var mysql=require('mysql2');
const express=require('express');
const bodyParser=require('body-parser');
const ap=express();
const config=require('../config');
const app = require('./chat');
//const app = require('./chat');
const dbConn=mysql.createConnection(config.db);

const jwt = require('jsonwebtoken');
const SECRET_KEY = process.env.SECRET_KEY || 'your_secret_key';




// it's in order to verify whether token belongs to the user or not
const verifyToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
        return res.status(403).json({ message: 'No token provided' });
    }

    const tokenParts = authHeader.split(' ');

    if (tokenParts[0] !== 'Bearer' || !tokenParts[1]) {
        return res.status(403).json({ message: 'Invalid token format' });
    }

    const token = tokenParts[1];

    jwt.verify(token, SECRET_KEY, (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        req.user = decoded;
        console.log("Successfully verified");
        next();
    });
};



//   // IMP req.user.mobile  ,  results





ap.post('/idLogin', verifyToken, async(req,res) =>{
    let sid, rid;
    const mobile=req.body.mobile;
    const id1='SELECT id from user where mobile=?';
    const id2='SELECT id from user where mobile=?';
    dbConn.query(id1, [req.user.mobile], (err,results) =>{
        if(err){
            console.log(err);
            res.status(500).json({
                message: "Error executing query for sender ID"
            })
        }
        else
        {
         sid=results[0].id;
         console.log('Sender ID is:')
         console.log(sid);
        }
    })
    
     
    dbConn.query(id2, [req.body.mobile], (err,results) =>{
        if(err){
            res.status(500).json({
                message: "Error executing query for receiver ID"
            })
        }
        else{
        rid=results[0].id; 
        console.log('Receiver id is :')
        console.log(rid);
        }
    })

    let z;
    let y;
    const query2='SELECT * FROM contacts WHERE SId=? AND RId=?';

    dbConn.query(query2, [sid,rid], (err,resp) =>{
        if(err)
        {
            console.log("Please Try Again");
        }
        else
        {
            z=resp;
            console.log(z);  
        }


        if(z.length>0)
        {
         console.log("SID =");
         console.log(sid);
         console.log("Entry is similar. Please Don't Repeat It!");
         res.status(401).json({
             message: "BAD REQUEST !"
         })
        
        } 
       else 
       {        
         const query='INSERT into contacts(SId, RId) VALUES(?,?)';
         
         dbConn.query(query, [sid,rid] , (err,results) =>{
         if(!err) 
          {
             dbConn.query('SELECT * from contacts where SId=? AND RId=? ', [sid,rid], (err,info) =>{
                 if(!err)
                 {
                     
                     if(info.length>0)
                     {
                        res.status(200).json({
                            message: "Data Succesfully Entered",
                            data: info
                        })

                     }
                     else{
                         res.status(400).json({
                             message :"Invalid Credentials"
                         })
                     }
                 }
                 else{
                      res.status(500).json({
                          message:"Internal Error"
                      })
                 }
             })

             
             
          }
          else
          {
                return res.status(500).json({
                message:"External ifServer Error"
            })
          }
          
        })
    
       }
          
    })
    
    

 
});


ap.post('/messagsend', async(req,res) =>{
    const{text,seid,reid}=req.body;
    const t=req.body.text;
    const sid=req.body.seid;
    const rid=req.body.reid;
    const seentime=0;
    const seendate=0;
    const q9='INSERT into messages(sid , rid , date , time , textmessage, seen , seentime , seendate) VALUES(?,?,?,?,?,?,?,?)';
    const q8= 'SELECT * from contacts where SId=? AND RId=?';
    
    dbConn.query(q8, [seid,reid], (err,info) =>{   // [sid],[rid] will it work?
        if(!err)
        {
            console.log(sid);
            console.log(rid);
            console.log(t);
            console.log(time);
            console.log(info);
            if(info.length>0)
            {
                console.log(" User Exists ");
                res.status(200).json({
                    message: " User Exists ! ",
                })
                
                dbConn.query(q9, [seid,reid,dateWithoutTime, time, text , seen, seentime, seendate], (err,data) =>{
                    if(!err)
                    {
                        dbConn.query('SELECT * from messages where sid=? AND rid=? AND date=?', [seid,reid, dateWithoutTime], (error,infor) =>{
                            if(!error)
                            {
                                if(infor.length>0)
                                {
                                    
                                        console.log(infor); 
                                }
                                else{
                                     res.status(400).json({
                                         message: "Internal Bad Request !!!"
                                     })
                                }
                            }
                            else
                            {
                                res.status(400).json({
                                    message: "Query not Running Successfully"
                                })
                            }
                        })
                        
                        
                    }
                    else
                    {
                        console.log(err);
                        res.status(500).json({
                            message : "Error Inserting Message",  
                        })
                    }
                })

            }
            else{
                 console.log("User Doesn't Exist. Please Check Contacts")
                 res.status(400).json({
                    message:" User doesn't exist. Please Check Contacts"
                 })
            }
        }
        else{
            console.log(err);
            res.status(500).json({
                message:"Outside Server Error"
            })
        }
    })


    
})


ap.post('/messagview', async(req,res) =>{
    const {myid, sid}=req.body;
    const query='SELECT * from messages where sid=? and rid=?';
    dbConn.query(query, [sid,myid] , (err,data) =>{
        if(!err)
        {
            if(data.length>0)
            {
                res.status(200).json({
                    message : "Message Successfully Viewed",
                    data : data
                })

    
                const q1= 'UPDATE messages SET seen = 1, seendate = CURDATE(), seentime = CURTIME() WHERE sid = ? AND rid = ? AND seen = 0'
               // var sql = "UPDATE customers SET address = 'Canyon 123' WHERE address = 'Valley 345'";

                dbConn.query(q1, [sid, myid], (error,data) =>{
                    if(!error)
                    {
                        console.log('HI');
                        const q2='SELECT * from messages WHERE sid=? and rid=? ';
                        dbConn.query(q2,[sid,myid], (er,gyaan) =>{
                            if(!er)
                            {
                              if(gyaan.length>0)
                              {
                                console.log("Message Time is Updated Successfully ")
                                console.log(gyaan);
                              }
                            }
                            else{
                                console.log("Time is not Updated Successfully !!")
                            }
                        })
                        
                    }
                    else{
                        res.status(500).json({
                            message:"Server Error"
                        })
                    }
                })
                
            }
        }
        else{
            res.status(500).json({
                message: "Server Error during Inserting Message!"
            })
        }
    })
     
})

// FROM BELOW NEW CODES

ap.delete('/.message delete_api', async(req,res) =>{
    const rid=req.body.id; // or I can use mobile
    const q='DELETE FROM messages WHERE rid=?';
    const q0='SELECT * from messages where rid=?'
    let details;
    dbConn.query(q0, [rid], (err,data) =>{
        if(err)
        {
            console.log(err);
        }
        else{
            details=data;
            console.log(details);
        }
    })

    dbConn.query(q, [rid], (err,data) =>{
        if(!err)
        {
            res.status(200).json({
                message: "Message Deleted !",
                data : details
            })
        }
        else{
            console.log(err);
            res.status(400).json({
                message:" Data not Deleted",
                data : err
            })
        }
    })

})


// perhaps I should ensure that two entries are not accurately equal (ek aur previous ke saath yehi karna hai [perhaps single contact case {sid,rid} ] )
ap.post('/groupcreate', (req, res) => {
    const { groupname, ...rest } = req.body;

    if (!groupname) {
        return res.status(400).json({
            message: "Please Enter Group Name"
        });
    }

    // To Extract mobile numbers dynamically
    const mobileNumbers = Object.keys(rest).filter(key => key.startsWith('m')).map(key => rest[key]);

    if (mobileNumbers.length === 0) {
        return res.status(400).json({
            message: 'At least one mobile number is required'
        });
    }

    // Retrieve mobile numbers from the database
    const q0 = 'SELECT mobile FROM user';
    dbConn.query(q0, (error, results) => {
        if (error) {
            return res.status(500).json({
                message: 'Database error',
                error: error
            });
        }

        if (results.length === 0) {
            return res.status(400).json({
                message: 'No mobile numbers found in the database'
            });
        }

        // Extract mobile numbers from database results
        const dbMobileNumbers = results.map(row => row.mobile);

        // Check if mobileNumbers is a subset of dbMobileNumbers
        const isSubset = mobileNumbers.every(num => dbMobileNumbers.includes(num));

        if (isSubset) {
            // Insert the group into the groups table
            const insertQuery = 'INSERT INTO groups (groupname, users) VALUES (?, ?)';
            dbConn.query(insertQuery, [groupname, JSON.stringify(mobileNumbers)], (insertErr, insertResults) => {
                if (insertErr) {
                    return res.status(500).json({
                        message: 'Error inserting group',
                        error: insertErr
                    });
                }

                res.status(200).json({
                    message: 'Group created successfully',
                    groupId: insertResults.insertId,
                    groupname,
                    mobileNumbers
                });
            });
        } else {
            res.status(400).json({
                message: 'Some mobile numbers are not found in the database',
            });
        }
    });
});

// I have to make below dynamic as well LATER. It didn't took into account repeated mobile entry

ap.post('/groupaddmobile', (req,res) =>{
    const{groupid, mobile}=req.body;
    if(!groupid || !mobile)
    {
        res.status(400).json({
            message: "Please Enter  Credentials!"
        })
    }

    const q1='SELECT mobile FROM user WHERE mobile=? ';
    dbConn.query(q1,[mobile], (err,data) =>{
        if(err)
        {
            return res.status(401).json({
                message : "Mobile Number Doesn't Match !"
            })
        }
        else
        {
            console.log("You are good to go")
            console.log(data);
            const q0='SELECT users from groups where id=?';
            let details;
            dbConn.query(q0, [groupid] ,(error,results) =>{
               if(error)
               {
                 return res.status(500).json({
                     message: "  Error retrieving Group",
                     error : error
                 })
               }
               if(results.length === 0)
               {
                   res.status(404).json({
                       message : "Some Error!"
                   })
               }

              const currentMobiles = JSON.parse(results[0].users);
              currentMobiles.push(mobile);

              const updateGroupQuery = 'UPDATE groups SET users = ? WHERE id = ?';
              dbConn.query(updateGroupQuery, [JSON.stringify(currentMobiles), groupid], (updateGroupErr) => {

                if (updateGroupErr) {
                    return res.status(500).json({ message: 'Error updating group', error: updateGroupErr });
                }

                res.status(200).json({
                    message: 'Mobile number added successfully',
                    groupid,
                    mobiles: currentMobiles
                });
            })  


        })
        }
    })

    

})

//
ap.post('/groupmessage', (req, res) => {
    const { groupname, sid, message } = req.body;

    // in above should pro use groupid bcz groupname can be same. I have implemented it in groupmobileadd(it's above)

    const date = new Date();
    const dat = date.toLocaleDateString();
    const time = date.toTimeString();
    
    const q0 = 'SELECT users FROM groups WHERE groupname = ?';

    dbConn.query(q0, [groupname], (error, results) => 
    {
        if (error) {
            return res.status(500).json({
                message: 'Database error',
                error: error
            });
        }

        if (results.length === 0) {
            return res.status(400).json({
                message: 'Group not found'
            });
        }

        const customers = results[0].users;

        const query = 'INSERT INTO group_messages (groupname, users, sid, message, senddate, sendtime) VALUES (?, ?, ?, ?, ?, ?)';
        dbConn.query(query, [groupname, customers, sid, message, dat, time], (err, data) => {
            if (err) {
                return res.status(500).json({
                    message: 'Error inserting data',
                    error: err
                });
            }

            res.status(200).json({
                message: 'Data inserted successfully',
                info: data
            });
        });
    });
});


module.exports=ap;
