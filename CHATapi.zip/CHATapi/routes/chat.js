const express = require('express');
const app = express();
const jwt = require('jsonwebtoken');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const config = require('../config');
const dbConn = mysql.createConnection(config.db);
var mymobile=require('./userRegister');


const SECRET_KEY = process.env.SECRET_KEY || 'your_secret_key'; // Securely stored secret key




app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const dbCon = mysql.createConnection(config.db);

// Middleware to verify token
const verifyToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
        return res.status(403).json({ message: 'No token provided' });
    }

    const tokenParts = authHeader.split(' ');

    if (tokenParts[0] !== 'Bearer' || !tokenParts[1]) {
        return res.status(403).json({ message: 'Invalid token format' });
    }

    const token = tokenParts[1];

    jwt.verify(token, SECRET_KEY, (err, decoded) => {
        if (err) {
            return res.status(401).json({ message: 'Unauthorized' });
        }
        req.user = decoded;
        console.log("Successfully verified");
        next();
    });
};

// Login beginning

// app.post('/login', (req, res) => {
//     const { email, password } = req.body;
//     const user = users.find(u => u.email === email && u.password === password);

//     if (user) {
//         const token = jwt.sign({ id: user.id, username: user.username, mobile: user.mobile }, SECRET_KEY, { expiresIn: '1h' });
//         res.status(200).json({ message: 'Login successful', token });
//     } else {
//         res.status(401).json({ message: 'Invalid credentials' });
//     }
// });

// Login endpoint

// Check user endpoint
app.get('/check-user/:mobile', verifyToken, (req, res) => {
    const { mobile } = req.body;

    if (req.mobile === mobile) {
        res.status(200).json({ message: 'Token belongs to the User', user: req.user.mobile });
    } else {
        res.status(403).json({ message: 'Token does not belong to the user' });
    }
});

// Chatting endpoint
app.post('/chatting', verifyToken, async(req, res) => {
    const date = new Date();
    const dateWithoutTime = date.toLocaleDateString();
    const time = date.toTimeString();
    const { mobile, message } = req.body;

    const passQuery = 'SELECT mobile FROM user WHERE mobile = ?';
    dbCon.query(passQuery, [mobile], (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Database query error' });
        }

        if (results.length === 0) {
            return res.status(404).json({ message: "Mobile Number doesn't match" });
        }

        const recmob = results[0].mobile; // ?
        
        console.log(recmob); 
        
        

        const query = 'INSERT INTO message (sender, receiver, date, time, message) VALUES (?, ?, ?, ?, ?)';
        dbCon.query(query, [req.user.mobile, recmob, dateWithoutTime, time, message], (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: 'Error sending message' });
             }
            else{
               res.status(200).json({
                message: 'Message sent successfully',
                data: message
                
            });
        }
        });
    });
});

// Receive messages endpoint
app.get('/receive', (req, res) => {
    dbCon.query('SELECT * FROM message', (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error displaying messages' });
        }

        res.status(200).json({ data: results });
    });
});



// app.listen(PORT, () => {
//     console.log(`Server running on http://localhost:${PORT}`);
// });

module.exports = app;
