const express = require('express');
const bcrypt = require('bcrypt');
const config = require('../config');
const router = express.Router();
const mysql = require('mysql');
const bodyparser=require('body-parser');
const  path = require('path');
const jwt= require('jsonwebtoken');
const validate=require('validator');
// const { response } = require('../..'); // Q What is this

const dbConn = mysql.createConnection(config.db);

 const SECRET_KEY = 'your_secret_key'; // what is it's purpose


    // filename: function(req, file, cb) {
    //     cb(null, new Date().toISOString()path.extname + (file.originalname);
    // }




// function validateEmail(email) {
//     return validator.isEmail(email);
//   }



router.post('/user-register', async (req, res, next) => {
    try {
        const password = await bcrypt.hash(req.body.password, 10);
        const { name, email, mobile } = req.body;
        const uuid = require('crypto').randomUUID(); // Generate a unique identifier
        // if (validateEmail(email)) {
        //     console.log("Valid email format.");
        //   } else {
        //     console.log("Invalid email format.");
        //   }

        const query = 'INSERT INTO user(uuid, name, email, password, mobile) VALUES(?,?,?,?,?)';
        dbConn.query(query, [uuid, name, email, password, mobile], (err, result) => {
            if (!err) {
                dbConn.query('SELECT * FROM user WHERE email = ?', [email], (err, info) => {
                    if (!err) {
                        res.status(200).json({
                            message: "User Registered Successfully",
                            data: info
                        });
                    } else {
                        console.log(err);
                        res.status(500).json({
                            message: "User has not been registered"
                        });
                    }
                });
            } 
            else {
                console.log(err);
                res.status(500).json({
                    error: "Something went wrong"
                });
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            error: "Server error during registration"
        });
    }
});
// For Token generation

// router.post('/login', (req, res) => {
//     const {email, password}=req.body;
//     const query = 'SELECT * FROM register WHERE email = ? , password=?';
//     if (query) {
//         const token = jwt.sign({ email: req.body.email }, SECRET_KEY, { expiresIn: '45s' });
//         res.json({ token, email });
//     } else {
//         res.status(401).json({ message: 'Invalid credentials' });
//     }
// });

// Middleware to verify token

// Protected route


 
//Above is end for token generation 'SELECT mobile FROM user WHERE email = ?';



        
        //let mail=req.body.email;
        
        // const q='SELECT mobile FROM user WHERE email=?';
        
        // let mobile;

        // dbConn.query(q, [email], async(err, data) =>{
        //    if(err) 
        //    {
        //        // throw(err);
        //       console.log(err);
        //    } 
        //    else {
        //      setMobile(data);
        //      console.log(mobile);
        //     }
        //  });
        

        //  function setMobile(value) 
        //  {
        //     if(value.length>0)
        //     {
        //         mobile = value[0].mobile;
                
        //     }
        // }

        let mobile;
        let token;

        router.post('/user-login', (req, res) => {
            const { email, password } = req.body; // Destructure email and password from request body
            const query = 'SELECT * FROM user WHERE email = ?'; // SQL query to check user credentials
            const q1='SELECT mobile from user WHERE email=?';

            dbConn.query(q1,[email], (err, data) =>{
                if(err)
                {
                    console.log(err);
                }
                else{
                    select(data);
                }
            })
            function select(value)
            {
                if(value.length>0)
                {
                 mobile=value[0].mobile;
                 console.log(mobile);
                }
            }


            dbConn.query(query, [email], (err, results) => {
               
                if (!err) {
                    if (query) 
                    {
                      token = jwt.sign({ email: req.body.email, mobile }, SECRET_KEY, { expiresIn: '600s' });
                    } 
                   else
                   {
                     res.status(401).json({ message: 'Invalid credentials' });
                   }

                    
                    if (results.length > 0)
                    {

                        bcrypt.compare(password, results[0].password, (error, result) => {
                            if (result) 
                            {
                                res.status(200).json({
                                    message: "Login successful",
                                    data: results[0],
                                    token:token
                                });
                            } 
                            else {
                                res.status(401).send('Invalid email or password');
                            }
                        });
                    } else {
                        res.status(401).send('Invalid email or password');
                    }
                } else {
                    console.log(err);
                    res.status(500).send('Login failed');
                }
            });
        });


        // router.post('/user-login', async (req, res, next) => {
        //     try {
        //         const { email, password } = req.body;
        //         console.log(req.body);
        
        //         // Promisify the dbConn.query function to use it with async/await
        //         const queryAsync = (query, params) => {
        //             return new Promise((resolve, reject) => {
        //                 dbConn.query(query, params, (err, results) => {
        //                     if (err) {
        //                         return reject(err);
        //                     }
        //                     resolve(results);
        //                 });
        //             });
        //         };
        
        //         // First query to get the mobile number
        //             // Second query to get the user details
        //             const userResults = await queryAsync('SELECT * FROM user WHERE email = ?', [email]);
        //             console.log("userResults", userResults);
        //             if (userResults.length > 0) {
        //                 const user = userResults[0];
        //                 const passwordMatch = await bcrypt.compare(password, user.password);
        //                 if (passwordMatch) {
        //                     const token = jwt.sign({ email: user.email, mobile }, SECRET_KEY, { expiresIn: '600s' });
        //                     res.status(200).json({
        //                         message: "Login successful",
        //                         data: user,
        //                         token: token
        //                     });
        //                 } else {
        //                     res.status(401).json({ message: "Invalid credentials" });
        //                 }
        //             } else {
        //                 res.status(401).json({ message: 'User not found' });
        //             }
                
        //     } catch (error) {
        //         console.error(error);
        //         res.status(500).json({
        //             error: "Server error during login"
        //         });
        //     }
        // });
        
        
        


// From below it's for authentication


// router.delete('/user-delete', async(req,res,next)=> 
//     try{
//         const id=req.body;
//         const query = 'DELETE * FROM register WHERE id = ?';
//         dbConn.query(query, [id], async(err,result) =>{
//             if(!err && results.length==0){
//                 res.status(200).json({
//                     message: "Data Deleted Successfully"
//                 })

//             }
//             else{
//                 res.status(401).json({
//                     message: "Error Deletion"
//                 })

//             }
//         })
//     }catch (error) {
//         console.error(error);
//         res.status(500).json({
//             error: "Server error during login"
//         });
//     }
// });



router.delete('/userdelete', async(req,res) =>{
    const mobile=req.body.mobile;
    //var sql = "DELETE FROM customers WHERE address = 'Mountain 21'";
    const q='DELETE from user where mobile=?';
    const q0='SELECT * FROM user where mobile=?';
    let info; // show this approach to VISHAL
    dbConn.query(q0,[mobile], (err,data) =>{
        if(!err)
        {
            if(data.length>0)
            {
                console.log("Data Successfully entered inside Variable")
            }
        }
        else
        {
            console.log(err);
        }
    })
    console.log(info);
    
    dbConn.query(q, [mobile], (error,data) =>{
        if(error)
        {
            console.log(error);

        }
        else{
            res.status(200).json({
                message :"Data Deleted !",
                data : info
            })
        }
    })

})

router.patch('/userupdate', async(req,res) =>{
    const mob=req.body.mobile;
    const n=req.body.name;
    let details;
    const query= 'SELECT * from user WHERE mobile=?';
    dbConn.query(query, [mob] , (err,data) =>{
        if(!err)
        {
           if(data.length>0)
           {
               dbConn.query('UPDATE user SET name=? WHERE mobile=?', [n,mob], (error, info) =>{
                   if(error)
                   {
                       console.log(error);
                   }
                   else
                   {
                       console.log("Updated Name List\n")
                       dbConn.query('SELECT * from user where mobile=?',[mobile], (err,info) =>{
                           if(err)
                           {
                               console.log(err);
                           }
                           else
                           {
                               console.log(info);
                                details=info  ;
                                console.log(details);
                           }
                       });
                   }
               } )
               res.status(200).json({
                   message  : "Entered mobile number is correct",
                   data : details
               })
           }
           else{
               res.status(400).json({
                   message: "Data is not found"
               })
           }
        }
        else{
            res.status(500).json({
                message: "Error is occuring! Please Check "
            })
        }
    })
})

module.exports = router;
