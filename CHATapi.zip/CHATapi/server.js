const http = require('http');

const app = require('./index');


const config=require('./config');
const server = http.createServer(app); // ?


server.listen(config.server.port, () =>{
    console.log(`Server is running on port ${config.server.port}`);
});



// const port=5500;
// const x=require('express');
// const y=x();
// y.listen(5500, ()=>{
//     console.log(`Server is running on http://localhost:${port}`);
// })  // traditional  way