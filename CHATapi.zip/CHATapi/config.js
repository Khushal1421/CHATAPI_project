module.exports={
    db:{
        host:"localhost",
        database:"Users",
        password:"",
        user:'root',
        port:'3308'
    },
    server: {
        port: 3000
    }
}